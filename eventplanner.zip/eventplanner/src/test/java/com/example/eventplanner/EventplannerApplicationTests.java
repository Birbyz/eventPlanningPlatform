package com.example.eventplanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventplannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
